﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteClasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void txtMatricula_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // criando o objeto, instanciando o objeto 
            Horista objHorista = new Horista();

            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalario.Text);
            objHorista.NumeroHora = Convert.ToDouble(textHora.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDtEntrada.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtFaltas.Text);
            // mostrando valores
            MessageBox.Show("Nome:" + objHorista.NomeEmpregado + "\n"
                + "Matricula:" + objHorista.Matricula + "\n" + "Tempo Trabalho:"
                + objHorista.TempoTrabalho() + "\n" + "Salário" +
                objHorista.SalarioBruto().ToString("N2"));

        }

        private void txtData_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtHora(object sender, EventArgs e)
        {

        }
    }
}
